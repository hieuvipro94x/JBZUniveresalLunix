# Printer COM Trace Report V9.2

- Serial opens: **0**
- TX requests: **0**
- TX payload bytes captured: **0**
- Complete EPL jobs ending P1: **0**
- Incomplete streams without final P1: **0**
- Failed WriteFile results: **0**
- Truncated payloads: **0**
- Payloads with mixed CRLF/bare-LF: **0**
- RX responses with data: **0**

## Đánh giá nhanh

- Không bắt được dữ liệu gửi máy in. Kiểm tra đúng profile Production và đúng tiến trình EXE.

## File đối chiếu

- `printer_serial.csv`: mở cổng, cấu hình COM, TX/RX và kết quả WriteFile.
- `printer_payloads/job_*.bin`: byte chính xác của từng lệnh in hoàn chỉnh.
- `printer_payloads/incomplete_*.bin`: dữ liệu khiến máy in có thể còn chờ lệnh.
