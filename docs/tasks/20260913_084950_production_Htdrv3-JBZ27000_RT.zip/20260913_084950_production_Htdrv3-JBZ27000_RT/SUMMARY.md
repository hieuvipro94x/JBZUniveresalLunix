# JBZ TRACE V9.2 BEHAVIOR TRACE — Tóm tắt session

- Profile: **production**
- Tổng event: **6295**
- Logger errors: **0**
- Event bị bỏ do queue đầy: **0**
- Frame I/O có thay đổi: **153**
- Pin activity: **16**
- Raw D2XX events: **10**
- Behavior events: **123**
- I/O transition candidates: **22**
- UI latency correlation rows: **463**
- Model artifacts/hash: **3**
- Printer COM events: **0**
- Printer TX requests: **0**
- Printer TX bytes captured: **0**
- Complete printer jobs ending P1: **0**
- Incomplete printer streams: **0**
- Kết quả UI: **FAIL, FAIL**
- Registration-related event: **0**
- Startup Discovery event: **0**

## Output

- `timeline.csv` — toàn bộ timeline đã lọc
- `events.jsonl` — event gốc
- `behavior_events.csv` — D2XX control, wait/event, process, VISA/GPIB và fan-in diagnostic
- `workflow_light.csv` — workflow Production nếu có
- `jbz_io_changes.csv` — frame decoder 80/A0/C0 (giả thuyết, emit mọi frame trong deep scan)
- `d2xx_raw_io.csv` — raw FT_Read/FT_Write/FT_GetQueueStatus, kể cả empty poll
- `scan_cadence.csv` — delta giữa Read/Queue/Frame để đo cadence thật
- `io_transition_candidates.csv` — added/removed IO giữa các frame để suy mapping
- `printer_serial.csv` — mở/cấu hình COM, dữ liệu TX/RX và kết quả từng lần ghi
- `printer_payloads/` — byte gốc của job hoàn chỉnh hoặc luồng chưa kết thúc
- `PRINTER_TRACE_REPORT.md` — báo cáo riêng cho lỗi máy in
- `startup_discovery.csv` — broad metadata file/registry/path-check trong ~2 giây đầu, không payload
- `static_target_analysis.json` / `STATIC_TARGET_ANALYSIS.md` — PE/import/string/signature static map
- `static_runtime_correlation.csv` / `STATIC_RUNTIME_CORRELATION.md` — static ↔ runtime hardware/call-path correlation
- `registration_timeline.csv` — timeline Registration
- `registration_callsites.csv` — callsite/backtrace liên quan
- `registration_dataflow.csv` — luồng Volume Serial / ID / input / validation
- `registration_flow.json` — tóm tắt machine-readable
- `REGISTRATION_DATAFLOW.md` — báo cáo data-flow
- `ida_targets.txt` — danh sách offset candidate để tra cứu tĩnh
- `REGISTRATION_SUMMARY.md` — tóm tắt Registration
- `MACHINE_REGISTRATION_REPORT.md` — báo cáo nhanh máy/ID/profile/status
- `profile_registration_storage.csv` — Tester Lock / Option Lock và nơi lưu
- `hardware_snapshot.json` — snapshot máy trước khi chạy EXE ở profile Registration

Production profile giữ V8.6 Deep Scan; Registration profile dùng V8.8 verified correlation. Không dùng Deep Scan để chạy production dài giờ vì overhead cao hơn.
